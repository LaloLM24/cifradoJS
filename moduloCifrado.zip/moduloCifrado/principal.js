function cifrado()
{
    const ocultar = new cifrado("mensaje", "llave");
    ocultar.cifrado
}