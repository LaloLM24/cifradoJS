echo "Se ejecutará el módulo de Cifrado, por favor sea paciente..."
sudo service apache2 start
firefox 127.0.01/moduloCifrado/index.html
