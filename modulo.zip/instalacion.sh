#!/bin/bash

echo "En este momento se instalará el software, un momento..."
sudo apt-get install apache2
sudo service apache2 start
unzip moduloCifrado -d /var/www/html
echo "finalizado"